import { and, asc, count, eq, exists, getTableColumns, inArray, or, sql, type SQL, type SQLWrapper } from 'drizzle-orm'
import type { H3Event } from 'h3'
import { z } from 'zod'
import { photoMaxBytes, remoteFields } from '../../shared/catalog'
import { remoteCompatibilities, remoteControls, remoteSearchTerms, searchTerms } from '../database/schema'

const controls = remoteControls
const compatible = remoteCompatibilities
const { photoBytes: _bytes, photoMime: _mime, ...controlFields } = getTableColumns(controls)

const filter = z.string().trim().max(160).optional()
const listQuery = z.object({
  page: z.coerce.number().int().min(1).max(1_000_000).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  q: filter,
  name: filter,
  brand: filter,
  model: filter,
  vipoCode: filter,
  track: z.enum(['0', '1']).optional(),
})

const writeInput = remoteFields.extend({
  photo: z.union([
    z.null(),
    z.string().max(Math.ceil(photoMaxBytes / 3) * 4).regex(/^[A-Za-z0-9+/]+={0,2}$/),
  ]).optional(),
})

function contains(field: SQLWrapper, value: string) {
  const escaped = value.replace(/[\\%_]/g, '\\$&')
  return sql`${field} LIKE ${`%${escaped}%`} ESCAPE '\\'`
}

type Db = ReturnType<typeof identityDb>
type ControlRow = Pick<typeof controls.$inferSelect, keyof typeof controlFields>

async function attachCompatibilities(db: Db, rows: ControlRow[]) {
  if (!rows.length) return []
  const matches = await db.select({
    remoteControlId: compatible.remoteControlId,
    brand: compatible.brand,
    model: compatible.model,
  }).from(compatible).where(inArray(compatible.remoteControlId, rows.map(row => row.id)))
    .orderBy(asc(compatible.brand), asc(compatible.model)).all()

  const byControl = new Map<string, { brand: string, model: string }[]>()
  for (const { remoteControlId, brand, model } of matches) {
    const items = byControl.get(remoteControlId) ?? []
    items.push({ brand, model })
    byControl.set(remoteControlId, items)
  }

  return rows.map(row => ({ ...row, compatibilities: byControl.get(row.id) ?? [] }))
}

export async function listControls(event: H3Event, publicOnly: boolean) {
  const { page, pageSize, name, brand, model, vipoCode, track, q } =
    await getValidatedQuery(event, listQuery.parse)
  const db = identityDb(event)
  const term = q?.replace(/\s+/g, ' ')
  const fields: SQL[] = []
  if (publicOnly) fields.push(eq(controls.active, true))
  if (name) fields.push(contains(controls.name, name))
  if (vipoCode) fields.push(eq(controls.vipoCode, vipoCode.toUpperCase()))
  const compatibleFilters = [
    eq(compatible.remoteControlId, controls.id),
    brand ? contains(compatible.brand, brand) : undefined,
    model ? contains(compatible.model, model) : undefined,
  ]
  const matchedAppliance = (...terms: SQL[]) =>
    exists(db.select({ id: compatible.id }).from(compatible).where(and(...compatibleFilters, ...terms)))

  if (term) {
    const words = term.split(' ')
    const controlText = sql`${controls.name} || ' ' || ${controls.vipoCode} || ' ' || coalesce(${controls.originalRemoteCode}, '')`
    const applianceText = sql`${controlText} || ' ' || ${compatible.brand} || ' ' || ${compatible.model}`
    const applianceMatch = matchedAppliance(...words.map(word => contains(applianceText, word)))
    if (brand || model) fields.push(applianceMatch)
    else fields.push(or(and(...words.map(word => contains(controlText, word))), applianceMatch)!)
  } else if (brand || model) {
    fields.push(matchedAppliance())
  }
  const where = and(...fields)
  const [rows, totals] = await Promise.all([
    db.select(controlFields).from(controls).where(where).orderBy(asc(controls.name), asc(controls.id))
      .limit(pageSize).offset((page - 1) * pageSize).all(),
    db.select({ total: count() }).from(controls).where(where).get(),
  ])

  const searchLabel = term ?? [name, brand, model, vipoCode].filter(Boolean).join(' ')
  if (publicOnly && track === '1' && page === 1 && searchLabel) {
    await recordSearch(db, searchLabel, where)
  }

  return { items: await attachCompatibilities(db, rows), total: totals?.total ?? 0, page, pageSize }
}

async function recordSearch(db: Db, label: string, where: SQL | undefined) {
  const normalized = label.toLowerCase().replace(/\s+/g, ' ')
  const matches = db.select({ id: controls.id }).from(controls).where(where).getSQL()
  const zeroResults = sql<number>`CASE WHEN EXISTS (${matches}) THEN 0 ELSE 1 END`
  await db.batch([
    db.insert(searchTerms).values({
      term: label,
      normalizedTerm: normalized,
      zeroResultCount: zeroResults,
    }).onConflictDoUpdate({
      target: searchTerms.normalizedTerm,
      set: {
        searchCount: sql`${searchTerms.searchCount} + 1`,
        zeroResultCount: sql`${searchTerms.zeroResultCount} + excluded.zero_result_count`,
        lastSearchedAt: sql`CURRENT_TIMESTAMP`,
      },
    }),
    db.run(sql`
      INSERT INTO remote_search_terms (remote_control_id, search_term_id, search_count)
      SELECT matched.id, search_terms.id, 1
      FROM (${matches}) AS matched CROSS JOIN search_terms
      WHERE search_terms.normalized_term = ${normalized}
      ON CONFLICT (remote_control_id, search_term_id)
      DO UPDATE SET search_count = remote_search_terms.search_count + 1
    `),
  ])
}

export function controlId(event: H3Event) {
  const id = getRouterParam(event, 'id')
  if (!id || !z.uuid().safeParse(id).success) throw notFound()
  return id
}

function notFound() {
  return createError({ statusCode: 404, message: 'Controle não encontrado' })
}

export async function getControl(event: H3Event, id: string) {
  const db = identityDb(event)
  const row = await db.select(controlFields).from(controls).where(eq(controls.id, id)).get()
  if (!row) throw notFound()
  const [item] = await attachCompatibilities(db, [row])
  return item!
}

export async function saveControl(event: H3Event, existingId?: string) {
  const { compatibilities, photo, ...fields } = await readValidatedBody(event, writeInput.parse)
  const id = existingId ?? crypto.randomUUID()
  const photoFields = photo === null
    ? { photoUrl: null, photoBytes: null, photoMime: null }
    : photo === undefined ? {} : controlPhoto(photo, id)
  const db = identityDb(event)
  const uniqueModels = new Map(compatibilities.map(item => [
    JSON.stringify([item.brand.toLowerCase(), item.model.toLowerCase()]), item,
  ]))
  const models = Array.from(uniqueModels.values(), item => ({ remoteControlId: id, ...item }))

  try {
    await db.transaction(async tx => {
      if (existingId) {
        const result = await tx.update(controls).set({ ...fields, ...photoFields })
          .where(eq(controls.id, id)).run()
        if (!result.rowsAffected) throw notFound()
        await tx.delete(compatible).where(eq(compatible.remoteControlId, id)).run()
      } else {
        await tx.insert(controls).values({ id, ...fields, ...photoFields }).run()
      }
      if (models.length) await tx.insert(compatible).values(models).run()
    })
  } catch (error) {
    const cause = error instanceof Error && error.cause instanceof Error ? error.cause : error
    if (cause instanceof Error && cause.message.includes('UNIQUE constraint failed: remote_controls.vipo_code')) {
      throw createError({ statusCode: 409, message: 'Código Vipo já cadastrado' })
    }
    throw error
  }

  return { id }
}

export async function deleteControl(event: H3Event, id: string) {
  const db = identityDb(event)
  await db.transaction(async tx => {
    await tx.delete(remoteSearchTerms).where(eq(remoteSearchTerms.remoteControlId, id)).run()
    await tx.delete(compatible).where(eq(compatible.remoteControlId, id)).run()
    const result = await tx.delete(controls).where(eq(controls.id, id)).run()
    if (!result.rowsAffected) throw notFound()
  })
}
